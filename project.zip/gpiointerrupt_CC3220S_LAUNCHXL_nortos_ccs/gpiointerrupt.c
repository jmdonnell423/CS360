#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/GPIO.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "ti_drivers_config.h"

// UART Global Variables
#define DISPLAY(x) UART_write(uart, output, x)
char output[64];
UART_Handle uart;
UART_Params uartParams;

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x00, "11X" },
    { 0x49, 0x00, "116" },
    { 0x41, 0x01, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;
I2C_Handle i2c;

// Timer Global Variables
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;
volatile int16_t setPoint = 25;  // Default set-point temperature
volatile int16_t currentTemp = 0;  // Current temperature from sensor
volatile uint32_t seconds = 0;  // Time in seconds since board reset

// Custom Timekeeping Variables
volatile uint32_t elapsedTime = 0;  // Custom elapsed time tracker

// Button Press Flags
volatile bool increaseSetPoint = false;
volatile bool decreaseSetPoint = false;

// UART Initialization
void initUART(void) {
    UART_init();  // Init the driver

    UART_Params_init(&uartParams);  // Configure the driver
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    uart = UART_open(CONFIG_UART_0, &uartParams);  // Open the driver
    if (uart == NULL) {
        snprintf(output, sizeof(output), "UART_open() failed\n");
        DISPLAY(strlen(output));
        while (1);  // Halt execution if UART fails to open
    }
}

// I2C Initialization
void initI2C(void) {
    int8_t i, found;
    I2C_Params i2cParams;

    snprintf(output, sizeof(output), "Initializing I2C Driver - ");
    DISPLAY(strlen(output));

    I2C_init();  // Init the driver

    I2C_Params_init(&i2cParams);  // Configure the driver
    i2cParams.bitRate = I2C_400kHz;

    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);  // Open the driver
    if (i2c == NULL) {
        snprintf(output, sizeof(output), "Failed\n\r");
        DISPLAY(strlen(output));
        while (1);
    }
    snprintf(output, sizeof(output), "Passed\n\r");
    DISPLAY(strlen(output));

    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;

    for (i = 0; i < 3; ++i) {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        snprintf(output, sizeof(output), "Is this %s? ", sensors[i].id);
        DISPLAY(strlen(output));

        if (I2C_transfer(i2c, &i2cTransaction)) {
            snprintf(output, sizeof(output), "Found\n\r");
            DISPLAY(strlen(output));
            found = true;
            break;
        }
        snprintf(output, sizeof(output), "No\n\r");
        DISPLAY(strlen(output));
    }

    if (found) {
        snprintf(output, sizeof(output), "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress);
        DISPLAY(strlen(output));
    } else {
        snprintf(output, sizeof(output), "Temperature sensor not found, contact professor\n\r");
        DISPLAY(strlen(output));
    }
}

// Read Temperature from Sensor
int16_t readTemp(void) {
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;

    if (I2C_transfer(i2c, &i2cTransaction)) {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;

        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;
        }
    } else {
        snprintf(output, sizeof(output), "Error reading temperature sensor (%d)\n\r", i2cTransaction.status);
        DISPLAY(strlen(output));
        snprintf(output, sizeof(output), "Please power cycle your board by unplugging USB and plugging back in.\n\r");
        DISPLAY(strlen(output));
    }

    return temperature;
}

// Timer Callback Function
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1;
    elapsedTime += 1000000;  // Increment elapsed time by 1 second (in microseconds)
    seconds++;  // Increment seconds since reset
}

// Timer Initialization
void initTimer(void) {
    Timer_Params params;

    Timer_init();  // Init the driver

    Timer_Params_init(&params);  // Configure the driver
    params.period = 1000000;  // 1 second in microseconds
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);  // Open the driver
    if (timer0 == NULL) {
        snprintf(output, sizeof(output), "Failed to initialize timer\n");
        DISPLAY(strlen(output));
        while (1);  // Halt execution if Timer fails to initialize
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        snprintf(output, sizeof(output), "Failed to start timer\n");
        DISPLAY(strlen(output));
        while (1);  // Halt execution if Timer fails to start
    }
}

// GPIO Callback Functions for Button Presses
void gpioButtonFxn0(uint_least8_t index) {
    increaseSetPoint = true;  // Set flag to increase the set-point
}

void gpioButtonFxn1(uint_least8_t index) {
    decreaseSetPoint = true;  // Set flag to decrease the set-point
}

// GPIO Initialization
void initGPIO(void) {
    GPIO_init();  // Initialize the GPIO driver

    // Configure the LED and button pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    // Turn on user LED
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    // Install Button callbacks
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);

    // Enable interrupts for the buttons
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
}

// Task Scheduler
void scheduler(void) {
    static uint32_t lastButtonCheck = 0, lastTempCheck = 0, lastUpdate = 0;

    if ((elapsedTime - lastButtonCheck) >= 200000) {  // 200ms for button checks
        lastButtonCheck = elapsedTime;

        // Check if any button press flags are set and update setPoint accordingly
        if (increaseSetPoint) {
            setPoint += 1;
            snprintf(output, sizeof(output), "Set-point increased to %d\n", setPoint);
            DISPLAY(strlen(output));
            increaseSetPoint = false;  // Reset the flag
        }
        if (decreaseSetPoint) {
            setPoint -= 1;
            snprintf(output, sizeof(output), "Set-point decreased to %d\n", setPoint);
            DISPLAY(strlen(output));
            decreaseSetPoint = false;  // Reset the flag
        }
    }

    if ((elapsedTime - lastTempCheck) >= 500000) {  // 500ms for temperature reads
        currentTemp = readTemp();  // Update the global currentTemp variable
        lastTempCheck = elapsedTime;

        // Control LED based on temperature and setpoint
        if (currentTemp < setPoint) {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn LED on
        } else {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Turn LED off
        }
    }

    if ((elapsedTime - lastUpdate) >= 1000000) {  // 1 second for UART output
        lastUpdate = elapsedTime;

        // Send the current temperature, setpoint, heat status, and time over UART
        snprintf(output, sizeof(output), "<%02d,%02d,%d,%04lu>\n",
                         currentTemp, setPoint, (currentTemp < setPoint), seconds);
        DISPLAY(strlen(output));
    }
}

/*
 *  ======== mainThread ========
 *  Main thread function
 */
void *mainThread(void *arg0)
{
    /* Initialize all peripherals */
    initUART();
    initI2C();
    initTimer();
    initGPIO();

    /* Main loop */
    while (1) {
        if (TimerFlag) {  // Check if the timer flag is set
            scheduler();  // Run the task scheduler
            TimerFlag = 0;  // Reset the timer flag
        }
    }

    return (NULL);
}






